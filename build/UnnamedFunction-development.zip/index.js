const Alexa = require('alexa-sdk');


const languageStrings = {
    'en': {
        translation: {
            SKILL_NAME: 'Speedy Mathematician',
            WELCOME: 'Are you a Speedy Mathematcian? Say begin to play the game.',
        },
    }
};


const handlers = {
    'LaunchRequest': function () {
        this.emit(':tell', this.t('WELCOME'));
    }
};

exports.handler = function(event, context, callback) {
    const alexa = Alexa.handler(event, context, callback);
    alexa.appId = "amzn1.ask.skill.a6c7f4da-789b-4fc4-9b19-c17c7f4eee36";
    alexa.resources = languageStrings;
    alexa.registerHandlers(handlers);
    alexa.execute();
};